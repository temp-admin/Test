package com.example.tablepaste

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: TableAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val input = findViewById<TextInputEditText>(R.id.inputEditText)
        val btn = findViewById<MaterialButton>(R.id.btnParse)
        val info = findViewById<TextView>(R.id.tvInfo)
        val recycler = findViewById<RecyclerView>(R.id.recycler)

        adapter = TableAdapter()
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        btn.setOnClickListener {
            val raw = input.text?.toString().orEmpty()
            val table = TableParser.parseTableText(raw)

            if (table == null) {
                info.text = "유효한 표가 아니에요. (최소 2줄 필요)"
                adapter.submit(TableData(emptyList(), emptyList()))
                return@setOnClickListener
            }

            info.text = "열 ${table.headers.size}개 / 행 ${table.rows.size}개"
            adapter.submit(table)
        }
    }
}
