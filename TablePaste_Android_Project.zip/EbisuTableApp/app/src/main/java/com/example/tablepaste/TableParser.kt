package com.example.tablepaste

object TableParser {
    fun parseTableText(raw: String): TableData? {
        val lines = raw
            .replace("\r\n", "\n")
            .replace("\r", "\n")
            .lines()
            .map { it.trimEnd() }
            .filter { it.isNotBlank() }

        if (lines.size < 2) return null

        fun splitLine(line: String): List<String> {
            return if (line.contains("\t")) {
                line.split("\t").map { it.trim() }
            } else {
                // fallback: 2+ spaces
                line.trim().split(Regex("\\s{2,}")).map { it.trim() }
            }
        }

        val headers = splitLine(lines.first())
        val rows = lines.drop(1).map { splitLine(it) }

        val normalizedRows = rows.map { r ->
            when {
                r.size == headers.size -> r
                r.size < headers.size -> r + List(headers.size - r.size) { "" }
                else -> r.take(headers.size)
            }
        }

        return TableData(headers = headers, rows = normalizedRows)
    }
}
