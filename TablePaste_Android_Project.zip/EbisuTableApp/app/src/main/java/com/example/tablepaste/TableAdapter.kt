package com.example.tablepaste

import android.graphics.Typeface
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TableAdapter : RecyclerView.Adapter<TableAdapter.RowVH>() {

    private var headers: List<String> = emptyList()
    private var rows: List<List<String>> = emptyList()

    fun submit(table: TableData) {
        headers = table.headers
        rows = table.rows
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = if (headers.isEmpty()) 0 else 1 + rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_table_row, parent, false)
        return RowVH(v)
    }

    override fun onBindViewHolder(holder: RowVH, position: Int) {
        val isHeader = position == 0
        val data = if (isHeader) headers else rows[position - 1]
        holder.bind(data, isHeader)
    }

    class RowVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val container: LinearLayout = itemView.findViewById(R.id.rowContainer)

        fun bind(cells: List<String>, isHeader: Boolean) {
            container.removeAllViews()

            val ctx = itemView.context
            val density = ctx.resources.displayMetrics.density
            val padH = (10 * density).toInt()
            val padV = (8 * density).toInt()

            cells.forEach { text ->
                val tv = TextView(ctx).apply {
                    this.text = text
                    setPadding(padH, padV, padH, padV)
                    setTextIsSelectable(true)
                    textSize = 13f
                    maxLines = 3
                    ellipsize = TextUtils.TruncateAt.END
                    minWidth = (120 * density).toInt()

                    if (isHeader) {
                        setTypeface(typeface, Typeface.BOLD)
                        setBackgroundColor(0xFFEFEFEF.toInt())
                    } else {
                        setBackgroundColor(0xFFFFFFFF.toInt())
                    }
                }

                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    rightMargin = (6 * density).toInt()
                }
                container.addView(tv, lp)
            }
        }
    }
}
