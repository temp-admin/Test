package com.example.tablepaste

data class TableData(
    val headers: List<String>,
    val rows: List<List<String>>
)
